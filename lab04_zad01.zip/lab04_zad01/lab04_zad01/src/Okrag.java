public class Okrag extends Figura{
    Punkt srodek;
    double r;

    public Okrag() {
        this.srodek.x = 0.0;
        this.srodek.y = 0.0;
        this.r = 0.0;
    }

    public Okrag(Punkt srodek, double r) {
        this.srodek = srodek;
        this.r = r;
    }

    public double getPowierzchnia(){
        return Math.PI*Math.pow(r,2);
    }

    public double getSrednica(){
        return 2*r;
    }

    public void setPromien(double r) {
        this.r = r;
    }

    public double getPromien() {
        return r;
    }

    public boolean wSrodku(Punkt pkt){
        if(Math.pow((pkt.x-srodek.x),2)+Math.pow((pkt.y-srodek.y),2)<=Math.pow(r,2))return true;
        return false;
    }

    public String opis()
    {
        return (super.opis()+"promien: "+r);
    }
}
