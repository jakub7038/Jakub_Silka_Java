public class Kwadrat extends Prostokat{
    public Kwadrat(double bok) {
        super(bok, bok);
    }

    public void setBok(double bok) {
        this.wys = bok;
    }

    public double getBok() {
        return wys;
    }

    public String opis()
    {
        return (super.opis()+" to kwadrat");
    }
}
