public class Main {
    public static void main(String[] args) {
        /*Punkt punkt = new Punkt();
        System.out.println("x("+punkt.x+","+punkt.y+")");*/


        /*Punkt[] punkty = new Punkt[]{
                new Punkt(),
                new Punkt(1.2,-2),
                new Punkt(5,-3.5)
        };

        for(Punkt item: punkty){
            item.opis();
        }

        for(Punkt item: punkty){
            item.zeruj();
        }

        for(Punkt item: punkty){
            item.opis();
        }*/

        /*
        Punkt punkt1 = new Punkt(10, 3);


        Okrag okrag = new Okrag(punkt1,10);
*/
        //Prostokat prostokat = new Prostokat(3,5);
        /*prostokat.punkt.opis();
        prostokat.punkt.przesun(10,3);
        prostokat.punkt.opis();*/
        //System.out.println(prostokat.opis());



    }
}