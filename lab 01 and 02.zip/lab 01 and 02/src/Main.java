import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //lab 1

        //l1_zad1();

        //l1_zad2();

        //l1_zad3();

        //l1_zad4();

        //l1_zad5();

        //l1_zad6();

        //l1_zad7();

        //______________________________________________
        //lab 2


        //zad 1

        /*
        System.out.println("podaj ilosc studnetów");
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        //zad1(n);
        zad1v2(n);
        */

        //zad2

        /*
        int ujemne = 0, dodatnie = 0;
        int id=0, iu=0;
        int n;
        for(int i=0;i<10;i++)
        {
            n=inint();
            if(n>0){dodatnie+=n;id+=1;}
            if(n<0){ujemne+=n;iu+=1;}
        }
        System.out.println("dodatnie: "+ dodatnie + " i: "+ id+" ujemne: "+ ujemne+ " iu: "+iu);

         */


        //zad3();

        //zad4();

        //zad5();

        //zad_1();

    }
    public static void l1_zad1()
    {
        System.out.println("podaj imię: ");
        String imie = instring();
        System.out.println("podaj wiek: ");
        int wiek = inint();
        System.out.println("imię: "+imie+"\nwiek: "+wiek);
    }

    public static void l1_zad2()
    {
        System.out.println("podaj liczbe a: ");
        int a = inint();
        System.out.println("podaj liczbe b: ");
        int b = inint();
        System.out.println("suma: "+a+" + "+b+" wynosi: "+(a+b));
        System.out.println("suma: "+a+" - "+b+" wynosi: "+(a-b));
        System.out.println("suma: "+a+" * "+b+" wynosi: "+(a*b));
    }

    public static void l1_zad3()
    {
        System.out.println("podaj liczbe: ");
        int n = inint();
        if(isEven(n)) System.out.println("jest parzysta");
        else System.out.println("nie jest parzysta");
    }

    public static void l1_zad4()
    {
        System.out.println("podaj liczbe: ");
        int n = inint();
        System.out.println(isdevidable(n));
    }
    public static void l1_zad5()
    {
        System.out.println("podah liczbe: ");
        int n = inint();
        System.out.println(potega3(n));
    }

    public static void l1_zad6()
    {
        System.out.println("podaj liczbe: ");
        int n = inint();
        System.out.println(root(n));
    }

    public static void l1_zad7()
    {
        System.out.println("podaj a: ");
        int a = inint();
        System.out.println("podaj b: ");
        int b = inint();
        System.out.printf("podaj c: ");
        int c = inint();
        System.out.println(is_triangle(a,b,c));
    }

    public static boolean is_triangle(int a, int b, int c)
    {
        if(a+b>c && a+c>b && b+c>a)return true;
        return false;
    }

    public static double root(int n)
    {
        return Math.sqrt(n);
    }

    public static int potega3(int n)
    {
        return (int)Math.pow(n,3);
    }

    public static boolean isdevidable(int n)
    {
        if(n%3==0 && n%5==0)return true;
        return false;
    }

    public static boolean isEven(int n)
    {
        if(n%2==0)return true;
        return false;
    }

    public static String instring()
    {
        Scanner input = new Scanner(System.in);
        return input.nextLine();
    }
    public static void zad_1()
    {
        int min,max;
        System.out.println("podaj min: ");
        min=inint();

        System.out.println("podaj max: ");
        max=inint();

        int size = 10;
        int[] tab = new int[size];
        for(int i=0;i<size;i++) {
            tab[i]=randomint(min, max);
        }

        int suma=0;

        for(int i : tab)
        {
            suma+=tab[i];
        }
    }
    public static void zad5()
    {
        Scanner input = new Scanner(System.in);
        String palindr = input.nextLine();
        palindrom(palindr);
    }



    public static int randomint(int min, int max)
    {
        return (int)(Math.random()*(max-min+1)+min);
    }

    public static void palindrom(String palindr)
    {
        System.out.println(palindr);
        char[] palindrom = palindr.toCharArray();
        boolean czy = true;
        int l = palindrom.length;
        for(int i=0;i<l;i++)
        {
            if(palindrom[i]!=palindrom[l-i-1]) {
                czy = false;
                break;
            }
        }
        if(czy) System.out.println("jest");
        else System.out.println("nie jest");
    }
    public static void zad3()
    {
        System.out.println("podaj n");
        int n = inint();
        int wynik;
        if(n<=0) System.out.println("niepoprawne dane");
        else {
            if (n % 2 == 0) wynik = (n/2)*((n/2)+1);
            else {
                n--;
                wynik = (n/2)*((n/2)+1);
            }
            System.out.println("wynik: "+wynik);
        }
    }

    public static void zad4()
    {
        System.out.println("podaj n");
        int n = inint();
        int wynik=0;

        if(n<1) System.out.println("niepoprawne dane");
        else {
            int[] tab = new int[n];
            for (int i = 0; i < n; i++) {
                //(-10,45) (0,55)
                tab[i]=(int)(Math.random()*(55)-10);
                System.out.println("tab["+(n+1)+"] = "+tab[i]);
            }
            for (int i = 0; i < n; i++) {
                if(tab[i]%2==0)wynik+=tab[i];
            }
            System.out.println(wynik);

        }
    }
    public static int inint()
    {
        Scanner input = new Scanner(System.in);
        return input.nextInt();
    }


    public static void zad1(int n)
    {
        Scanner input = new Scanner(System.in);
        System.out.println(n);
        int x=0;
        double wynik=0;

        while(x<n)
        {
            System.out.println("podaj ilość pkt: ");
            wynik += (double) input.nextInt();
            x++;
        }

        wynik/=n;
        System.out.println("wynik: "+ wynik);
    }

    public static void zad1v2(int n)
    {
        Scanner input = new Scanner(System.in);
        System.out.println(n);
        int x=0;
        double wynik=0;
        int[] pkt = new int[n];
        while(x<n)
        {
            System.out.println("podaj ilość pkt: ");
            pkt[x] = input.nextInt();
            wynik+=pkt[x];
            x++;
        }

        wynik/=n;
        System.out.println("wynik: "+ wynik);
    }

}