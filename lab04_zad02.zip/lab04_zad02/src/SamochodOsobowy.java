import java.util.Date;

public class SamochodOsobowy extends Samochod{
private double Waga, Pojemnosc_Silnika;
private int ilosc_osob;

    public double getWaga() {
        return Waga;
    }

    public void setWaga(double waga) {
        Waga = waga;
    }

    public double getPojemnosc_Silnika() {
        return Pojemnosc_Silnika;
    }

    public void setPojemnosc_Silnika(double pojemnosc_Silnika) {
        Pojemnosc_Silnika = pojemnosc_Silnika;
    }

    public int getIlosc_osob() {
        return ilosc_osob;
    }


    public void setIlosc_osob(int iloss_osob) {
        this.ilosc_osob = iloss_osob;
    }


    public SamochodOsobowy(String Marka, String Model, String Nadwozie, String Kolor, double Przebieg, Date Date, double Waga, double Pojemnosc_Silnika,
    int iloss_osob){
        super(Marka,Model,Nadwozie,Kolor,Przebieg,Date);
        this.ilosc_osob = ilosc_osob;
        this.Waga = Waga;
        this.Pojemnosc_Silnika = Pojemnosc_Silnika;
    }

    public void View_Samochod()
    {
    super.View_Samochod();
        System.out.println(" Waga: "+Waga+" ilosc osób: "+ilosc_osob+" pojemnosc silnika: "+Pojemnosc_Silnika);
    }

}
