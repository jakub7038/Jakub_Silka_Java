import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Date date1 = new Date(1967,12,12);
        SamochodOsobowy auto1 = new SamochodOsobowy("Ford","GT40","coupe","czerwono-biały",520.2, date1,908,4.6,2);

        auto1.View_Samochod();
        Date date2 = new Date(2003, 9, 5);
        Samochod auto2 = new Samochod();
        auto2.Marka = "Fiat";
        auto2.Model = "Albea";
        auto2.Nadwozie = "Hatchback";
        auto2.Kolor = "Srebrny";
        auto2.Przebieg = 920;
        auto2.Date = date2;
        auto2.View_Samochod();

        Samochod auto3 = new Samochod("Ford","GT40","coupe","czerwono-biały",520.2, date1);
        auto3.View_Samochod();
    }
}