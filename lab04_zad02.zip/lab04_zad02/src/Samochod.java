import java.util.Date;

public class Samochod {
    protected String Marka, Model, Nadwozie, Kolor;
    protected double Przebieg;
    protected Date Date;

    public String getMarka() {
        return Marka;
    }

    public void setMarka(String marka) {
        Marka = marka;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public String getNadwozie() {
        return Nadwozie;
    }

    public void setNadwozie(String nadwozie) {
        Nadwozie = nadwozie;
    }

    public String getKolor() {
        return Kolor;
    }

    public void setKolor(String kolor) {
        Kolor = kolor;
    }

    public Double getPrzebieg() {
        return Przebieg;
    }

    public void setPrzebieg(Double przebieg) {
        Przebieg = przebieg;
    }

    public Date getDate() {
        return Date;
    }

    public void setDate(Date date) {
        this.Date = date;
    }

    public Samochod(String Marka, String Model, String Nadwozie, String Kolor, double Przebieg, Date Date)
    {
        this.Marka = Marka;
        this.Model = Model;
        this.Nadwozie = Nadwozie;
        this.Kolor = Kolor;
        this.Przebieg = Przebieg;
        this.Date = Date;
    }

    public Samochod()
    {
    }

    public void View_Samochod()
    {
        System.out.println("Marka: "+this.Marka+" Model: "+ this.Model +" Nadwozie: "+this.Nadwozie+" Kolor: "+this.Kolor+" Przebieg: "+this.Przebieg+" Date: "+this.Date);
    }


}
