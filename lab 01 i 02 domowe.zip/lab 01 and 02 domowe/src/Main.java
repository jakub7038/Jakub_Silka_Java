import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {

        //lab1_zad1();

        //lab1_zad2();

        //lab1_zad3();

        //lab1_zad4();

        //lab1_zad5();

        //lab1_zad6();

        //lab2_zad1();

        //lab2_zad2();

        //lab2_zad3();

        //lab2_zad4();

        //lab2_zad5();

        //lab2_zad6();

        //lab2_zad7();

    }

    public static void lab1_zad1()
    {
        System.out.println("podaj x: ");
        double x = input_double();
        System.out.println(f1(x));
    }

    public static double f1(double x)
    {
        System.out.println("podaj a: ");
        double a = input_double();
        System.out.println("podaj b: ");
        double b = input_double();
        System.out.println("podaj c: ");
        double c = input_double();
        x = a*x*x + b*x + c;
        return x;
    }
    public static void lab1_zad2()
    {
        System.out.println("podaj x: ");
        double x = input_double();
        System.out.println(a(x));
        System.out.println(b(x));
        System.out.println(c(x));
    }

    public static double a(double x)
    {
        if(x==0)return 0;
        if(x>0)return x*2;
        return  x*(-3);
    }

    public static double b(double x)
    {
        if(x>=1)return x*x;
        return x;
    }

    public static double c(double x)
    {
        if(x==2)return 8;
        if(x>2)return x+2;
        return x-4;
    }


    public static void lab1_zad3()
    {
        int x = input_int();
        int y = input_int();
        int z = input_int();
        int[] tab = {x,y,z};
        Arrays.sort(tab);
        System.out.println(tab[0]+" "+tab[1]+" "+tab[2]);
    }
    public static void lab1_zad4()
    {
        System.out.println("czy pada deszcz: ");
        boolean pada = input_boolean();
        System.out.println("czy jest bus: ");
        boolean bus = input_boolean();
        if(bus)
        {
            if(pada) System.out.println("wez parasol");
            System.out.println("Dostaniesz się");
            if(!pada) System.out.println("milego dnia i pieknej pogody");
        }
        else System.out.println("nie dostaniesz sie");
    }
    public static void lab1_zad5()
    {
        System.out.println("czy jest zniżka: ");
        boolean sale = input_boolean();
        System.out.println("czy masz premię: ");
        boolean premia = input_boolean();

        if(sale||premia)
        {
            System.out.println("Możesz kupić samochód !");
            if(!premia)System.out.println("Zniżki na samochód nie ma");
        }
        else
        {
            System.out.println("Zakup samochód trzeba odłożyć na później...");
            System.out.println("Zniżki na samochód nie ma");
        }
    }
    public static void lab1_zad6()
    {
        System.out.println("podaj liczbę a: ");
        int a = input_int();
        System.out.println("podaj liczbę b: ");
        int b = input_int();
        System.out.println("wpisz 1 aby dodać, 2 aby odjąć, 3 aby pomnożyć, lub 4 aby podzielić: ");
        int c = input_int();
        switch(c){
            case 1:
                System.out.println((a+b));
                break;
            case 2:
                System.out.println((a-b));
                break;
            case 3:
                System.out.println((a*b));
                break;
            case 4:
                if(b>a) System.out.println(a+"/"+b);
                else {
                    int r = a % b;
                    a -= r;
                    System.out.println((a / b) + " reszta: " + r);
                }
                    break;
            default:
                System.out.println("bruh");
        }

    }

    public static void lab2_zad1()
    {
        int[] tab = {randomint(1,100),randomint(-10,20),randomint(2,30)};
        int suma = 0, sumav2 = 0;
        double average;

        for(int i = 0; i < tab.length ; i++)
        {
            suma += tab[i];
        }

        for(int i : tab)
        {
            sumav2 += i;
        }
        System.out.println("suma "+suma+" "+sumav2);
        average = (double)suma/tab.length;
        System.out.println("srednia: "+average);

    }

    public static void lab2_zad2()
    {
        int[] tab1 = {1,2,3,4,5,6};
        int[] tab2 = {1,2,3,4,5};
        for(int i = 0; i<tab1.length; i+=2)
        {
             System.out.println(tab1[i]);
        }

        for(int i = 0; i<tab2.length; i+=2)
        {
            System.out.println(tab2[i]);
        }
    }

    public static void lab2_zad3()
    {
        System.out.println("podaj text: ");
        String text = input_string().toUpperCase();
        for(char character : text.toCharArray())
        {

            System.out.println(character);
        }
    }

    public static void lab2_zad4()
    {
        System.out.println("podaj 5 słów: ");
        String[] slowa = {input_string(), input_string(), input_string(), input_string(), input_string()} ;
        for(int i=slowa.length-1; i > -1; i--)
        {
            char[] literki = slowa[i].toCharArray();
             for(int j= literki.length-1;j > -1; j--)
             {
                 System.out.print(literki[j]);
             }
            System.out.println();
        }
    }

    public static void lab2_zad5()
    {
        System.out.println("podaj 8 liczb");
        int[] tab = {input_int(), input_int(), input_int(), input_int(),
        input_int(),input_int(),input_int(),input_int()};
        Arrays.sort(tab);
        for(int i : tab) System.out.println(i);
    }

    public static void lab2_zad6()
    {
        int[] tab = {input_int(), input_int(), input_int(), input_int(), input_int()};
        for(int i : tab) System.out.println(factorial(i));
    }

    public static void lab2_zad7()
    {
        String[] string1 = {"abc","bca","dca"};
        String[] string2 = {"abc","bca","dca"};
        boolean equal = true;

        if(string1.length==string2.length)
        {
            for(int i=0; i<string1.length; i++)
            {
                if(!string1[i].equals(string2[i])){
                    equal=false;
                    break;
                }
            }
        }
        else equal=false;

        if(equal) System.out.println("takie same");
        else System.out.println("różne");
    }

    public static int factorial(int n)
    {
        int wynik = 1;
        for(int i=2;i<=n;i++)
        {
            wynik*=i;
        }
        return wynik;
    }
    public static int randomint(int min, int max)
    {
        return (int)(Math.random()*(max-min+1)+min);
    }
    public static Boolean input_boolean()
    {
        Scanner input = new Scanner(System.in);
        return input.nextBoolean();
    }
    public static String input_string()
    {
        Scanner input = new Scanner(System.in);
        return input.nextLine();
    }

    public static int input_int()
    {
        Scanner input = new Scanner(System.in);
        return input.nextInt();
    }

    public static double input_double()
    {
        Scanner input = new Scanner(System.in);
        return input.nextDouble();
    }
}