import java.time.*;
public class Budynek {

    private String Nazwa = "budynek";
    private int Liczba_piętr = 1;

    private int wiek=0;

    public void setWiek(int wiek){
        this.wiek = 2024-date.getYear();
    }

    LocalDate date = LocalDate.of(1,1,1);

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getNazwa() {
        return Nazwa;
    }

    public void setNazwa(String nazwa) {
        Nazwa = nazwa;
    }

    public int getLiczba_piętr() {
        return Liczba_piętr;
    }

    public void setLiczba_piętr(int liczba_piętr) {
        this.Liczba_piętr = liczba_piętr;
    }


    public void view(){
        System.out.println("Nazwa: "+Nazwa+" liczba piętr: "+Liczba_piętr+" wiek budynku: "+(2024-date.getYear()));
    }

}
