import java.time.*;

public class Main {
    public static void main(String[] args) {

        LocalDate date = LocalDate.of(2000,2,12);
        String nazwa= "budynio";
        int Liczba_piętr = 10;

        Budynek budynek1 = new Budynek();
        budynek1.setDate(date);
        budynek1.setNazwa(nazwa);
        budynek1.setLiczba_piętr(Liczba_piętr);
        budynek1.view();

        Budynek budynek2 = new Budynek();
        budynek2.setDate(LocalDate.of(2010,10,12));
        budynek2.setNazwa("galeria");
        budynek2.setLiczba_piętr(23);
        budynek2.view();

        Budynek budynek3 = new Budynek();
        budynek3.setDate(LocalDate.of(2008,6,10));
        budynek3.setNazwa("Auchan");
        budynek3.setLiczba_piętr(1);
        budynek3.view();

    }
}